import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-approve-transaction',
  templateUrl: './approve-transaction.component.html',
  styleUrls: ['./approve-transaction.component.css']
})
export class ApproveTransactionComponent implements OnInit {
  constructor() { }
  ngOnInit() {
  }
}
